<?php
@set_time_limit(0);
session_start();

require_once "../share/db.class.php";
require_once "../share/WebVisitorReserveManager.php";

$wvrm = new WebVisitorReserveManager();
$wvrm->SetParkInfo();


if (isset($_GET['server-refresh'])) {
    // SSE 설정
    header('Content-Type: text/event-stream');
    header('Cache-Control: no-cache');
    header('Connection: keep-alive');

    // 새로 고침이 필요한 경우
    echo "data: {\"refreshRequired\": true}\n\n";
    flush();  // 데이터를 클라이언트로 전송
    exit();
}

// 세션이 없으면 바로 로그아웃 처리
if (!isset($_SESSION["DCUNo"])) {
    session_unset();
    session_destroy();

    // 세션 ID를 제거 (쿠키에서 세션 ID를 삭제해야 완전한 종료)
    setcookie(session_name(), '', time() - 3600, '/'); // 세션 쿠키 만료
    session_regenerate_id(true);  // 세션 ID 새로 생성 (보안상 권장)

    $wvrm->MainDB->disconnect();
    echo json_encode(array('date' => '', 'data' => [], 'logincheck' => 'logout'));
    exit();
}

if (!$_GET['date']||$_GET['date'] == "") {
    $_GET['date'] = date('Y-m-d H:i:s');
}

$date = $_GET['date'];
$data = [];
$logincheck = '';

// $res = $db->MainDB->query('SELECT * FROM webdcpurchinfo WHERE RequestDate < %s AND WDCStatus = 0 AND PaymentKey is NULL ORDER BY RequestDate DESC', $date);

// if (count($res) > 0) {
//     foreach ($res as $item) {
//         $data[] = $item;
//         $date = $item['RequestDate'];
//     }
// }

// $db->MainDB->disconnect();
// echo json_encode(array('date' => $date, 'data' => $data, 'logincheck' => $logincheck));

try {
    // DB 쿼리 실행
    $res = $wvrm->MainDB->query('SELECT * FROM webdcpurchinfo WHERE RequestDate < %s AND WDCStatus = 0 AND PaymentKey is NULL ORDER BY RequestDate DESC', $date);

    if (!empty($res)) {
        foreach ($res as $item) {
            $data[] = $item;
            $date = $item['RequestDate'];  // 마지막 RequestDate로 업데이트
        }
    }

    $wvrm->MainDB->disconnect();
    // 정상적인 JSON 응답
    echo json_encode(array('date' => $date, 'data' => $data, 'logincheck' => $logincheck));
} catch (Exception $e) {
    
    $wvrm->MainDB->disconnect();
    // 예외가 발생했을 때 JSON 형식으로 오류 메시지 반환
    echo json_encode(array('error' => 'Server error: ' . $e->getMessage()));
}
?>