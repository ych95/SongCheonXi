<?php
    session_start();
    require_once "../share/WebVisitorReserveManager.php";
        
    $wvrm = new WebVisitorReserveManager();
    $wvrm->SetParkInfo();

    //아이디 일부 가리기
    function maskString($str) {
        $length = strlen($str);
    
        if ($length > 4) {
            // 앞 2자리를 가져오고, 나머지는 '*'로 표시, 마지막 문자는 그대로
            $masked = substr($str, 0, 2) . str_repeat('*', $length - 3) . substr($str, -1);
        }    
        return $masked;
    }

    $findType = $_POST["FindType"];//아이디를 찾는 건지 비밀번호를 찾는 건지 구분
	$unit = $_POST["Unit"];
	$number = $_POST["Number"];
    $telNum = $_POST["TelNum"];

    $results["success"] = true;

    if($findType == "id"){//아이디찾기 일 경우 '동', '호수', '핸드폰번호' 매칭
        $result = $wvrm->MainDB->queryFirstRow("SELECT UserID FROM userinfo where Unit = %s AND Number = %s AND TelNum = %s AND Activated = 1", $unit, $number, $telNum);

        if(count($result)>0){
            $results["msg"] = "\n아이디  : ".maskString($result['UserID']);
        }else{
            $results["success"] = false;
            $results["msg"] = $result."등록이 안된 세대 이거나 입력정보가 잘못되었습니다.";    
        }
    }
    else if($findType == "pw"){//비밀번호 찾기 일 경우 '동', '호수', '핸드폰번호', '유저아이디' 매칭
        $userID = $_POST["UserID"];
        $result = $wvrm->MainDB->queryFirstRow("SELECT UserPW FROM userinfo where Unit = %s AND Number = %s AND TelNum = %s AND UserID = %s AND Activated = 1", $unit, $number, $telNum, $userID);

        if(count($result)>0){
            $results["msg"] = "\n비밀번호 : ".$result['UserPW']."\n";
        }else{
            $results["success"] = false;
            $results["msg"] = "등록이 안된 세대 이거나 입력정보가 잘못되었습니다.";    
        }
    }

    echo json_encode($results, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE);
    $wvrm->MainDB->disconnect();
    exit();
?>