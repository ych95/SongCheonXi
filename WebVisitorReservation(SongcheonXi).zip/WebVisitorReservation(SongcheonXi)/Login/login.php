<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    require_once "../share/WebVisitorReserveManager.php";
    $wvrm = new WebVisitorReserveManager();
    $wvrm->SetParkInfo();

    $userID = isset($_POST["UserID"]) ? $_POST["UserID"] : '';
    $userPW = isset($_POST["UserPW"]) ? $_POST["UserPW"] : '';

    // 아이디와 비밀번호가 모두 입력되었는지 확인
    if (!empty($userID) && !empty($userPW)) {
        // 로그인 시도
        $login_data = $wvrm->Login($userID, $userPW);

        // 로그인 성공
        if ($login_data[1] == 0) {
            $_SESSION["UserNo"] = $login_data[0]["UserNo"];
            $_SESSION["Unit"] = $login_data[0]["Unit"];
            $_SESSION["Number"] = $login_data[0]["Number"];
            $_SESSION["UserClass"] = $login_data[0]["UserClass"];

            setcookie("UserID", $userID, time() + 60 * 60 * 24 * 30, "/");
            setcookie("UserPW", $userPW, time() + 60 * 60 * 24 * 30, "/"); 
            
            // 관리자와 유저 구분하여 메인페이지 전환
            if ($_SESSION["UserClass"] == "0") {
                $location = "../Admin/adminMain.html";
            } else if ($_SESSION["UserClass"] == "1") {
                $location = "../User/userMain.html";
            }
        } else {
            // 로그인 실패 메시지 설정
            $_SESSION['LoginMessage'] = '아이디 또는 비밀번호가 잘못되었습니다.';
            $location = "../Login/login.html";
        }
    } else {
        // 아이디 또는 비밀번호 입력되지 않았을 때 메시지 설정
        $_SESSION['LoginMessage'] = '아이디와 비밀번호를 입력해주세요.';
        $location = "../Login/login.html";
    }

    echo $location;
    $wvrm->MainDB->disconnect();
    header("Location: ".$location);
    exit();
}
?>