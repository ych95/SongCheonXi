<?php
session_start();
    session_unset();
    session_destroy();

    setcookie("UserID", "", time() - 3600, "/");
    setcookie("UserPW", "", time() - 3600, "/");

    // 세션 ID를 제거 (쿠키에서 세션 ID를 삭제해야 완전한 종료)
    setcookie(session_name(), '', time() - 3600, '/'); // 세션 쿠키 만료
    session_regenerate_id(true);  // 세션 ID 새로 생성 (보안상 권장)

    // 리디렉션
    header("Location: login.html");
    exit();
?>