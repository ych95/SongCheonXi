<?php
    session_start();
    require_once "../share/WebVisitorReserveManager.php";

    $wvrm = new WebVisitorReserveManager();
    $wvrm->SetParkInfo();

    $userid = isset($_POST["UserID"]) ? $_POST["UserID"] : '';
    $userpw = isset($_POST["UserPW"]) ? $_POST["UserPW"] : '';
    $userpw2 = isset($_POST["UserPW2"]) ? $_POST["UserPW2"] : '';
    $telnum = isset($_POST["TelNum"]) ? $_POST["TelNum"] : '';
    $unit = isset($_POST["Unit"]) ? $_POST["Unit"] : '';
    $number = isset($_POST["Number"]) ? $_POST["Number"] : '';

    $location = "../Login/sign_up.html";

    if (empty($userid) || empty($userpw)) {
        $_SESSION["RegisterMessage"] = '아이디와 비밀번호를 확인하여주세요.';
    } else if (empty($telnum)) {
        $_SESSION["RegisterMessage"] = '전화번호를 확인하여주세요.';
    } else if (empty($unit) || empty($number)) {
        $_SESSION["RegisterMessage"] = '동과 호수를 확인하여주세요.';
    } else if(strlen($userid) < 4){
        $_SESSION["RegisterMessage"] = 'ID는 4자리이상 입력하여주세요.';
    } else if($userpw != $userpw2){
        $_SESSION["RegisterMessage"] = '입력한 비밀번호가 다릅니다.';
    } else if($unit == "-1" || $number == "-1"){
        $_SESSION["RegisterMessage"] = '동/호수를 확인하여주세요.';
    }
    else{//회원가입 양식 맞으면 DB 가입처리

        //가입이력이 있는지 검사
        $result = $wvrm->MainDB->query("SELECT * FROM userinfo WHERE Activated = 1 AND UserID = %s AND Activated = 1", $userid);//아이디 중복검사

        if(count($result) == 0){
            $result = $wvrm->MainDB->query("SELECT * FROM userinfo WHERE  Activated = 1 AND Unit = %s AND Number = %s AND Activated = 1", $unit, $number);//세대 중복검사

            if(count($result) == 0){
                $result = $wvrm->MainDB->query("SELECT * FROM userinfo WHERE Activated = 1 AND TelNum = %s AND Activated = 1", $telnum);//전화번호 중복검사

                if(count($result) == 0){
                    //가입처리(DB 등록)
                    $wvrm->MainDB->query("INSERT INTO userinfo (UserID, UserPW, Unit, Number, TelNum, MemberDate) VALUES (%s, %s, %s, %s, %s, now())", $userid, $userpw, $unit, $number, $telnum);

                    //정상적으로 가입처리되었는지 검사
                    $result = $wvrm->MainDB->query("SELECT * FROM userinfo WHERE Activated = 1 AND UserID = %s AND Unit = %s AND Number = %s AND TelNum = %s", $userid, $unit, $number, $telnum);

                    if(count($result) > 0){
                        //바로 로그인
                        $login_data = $wvrm->Login($userid, $userpw);

                        $_SESSION["UserNo"] = $login_data[0]["UserNo"];
                        $_SESSION["Unit"] = $login_data[0]["Unit"];
                        $_SESSION["Number"] = $login_data[0]["Number"];
                        $_SESSION["UserClass"] = $login_data[0]["UserClass"];
                        $_SESSION['LoginMessage'] = "회원가입을 축하드립니다.";

                        //관리자와 유저 구분하여 메인페이지 전환
                        if ($_SESSION["UserClass"] == "0") {
                            $location = "../Admin/adminMain.html";
                        } else if ($_SESSION["UserClass"] == "1") {
                            $location = "../User/userMain.html";
                        }
                    }else{//DB 삽입에러 
                        $_SESSION['RegisterMessage'] = "다시 시도하여주세요.";
                    }
                }else{
                    $_SESSION['RegisterMessage'] = "이미 등록된 전화번호 입니다.";
                }
            }else{
                $_SESSION['RegisterMessage'] = "이미 가입한 세대 입니다.";
            }
        }else{
            $_SESSION['RegisterMessage'] = "사용중인 아이디입니다.";
        }    
    }

    $wvrm->MainDB->disconnect();
    header("Location: ".$location);
    exit();
?>