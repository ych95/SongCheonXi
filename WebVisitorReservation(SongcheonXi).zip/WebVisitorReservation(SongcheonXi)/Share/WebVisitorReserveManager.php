<?php
require_once "db.class.php";
require_once "envini.php";

class SubParkInfo
{
	public $DB;				### 주차장 서버 DB
	public $ParkInfo;		### 주차장 정보 테이블 정보
	public $DCInfos = [];	### 할인정보 테이블 [웹 할인과 연동된 할인정보]	
	public $DCPriceInfos = [];	### 할인가격 정보		
	public $PurchInfos = [];
	public $ParkType; 		### 노상주차장과 공영주차장 구분
}


class SubUserInfo
{
	public $UserNo;
	public $Unit;
	public $Number;
	public $TelNum;
	public $UserClass;
	public $MemberDate;
	public $UsedInfos;
}

class WebVisitorReserveManager
{
	public $UserNo;
	public $MainDB;
	public $SognoDB;
	public $ParkInfo;
	public $UserInfos;
	public $UsedInfos;

	function Login($id, $pw) //id가 없으면 1, pw가 틀렸으면 2, 모두 정상입력이면 0
	{
		$results = [$this->MainDB->queryFirstRow("SELECT * FROM userinfo WHERE UserID = %s and Activated = 1", $id), 0];

		if (sizeof($results[0]) > 0) {
			$results = [$this->MainDB->queryFirstRow("SELECT * FROM userinfo WHERE UserID = %s AND UserPW = %s and Activated = 1", $id, $pw), 0];

			if (sizeof($results[0]) > 0) {
			} else { //비밀번호 틀림
				$results[1] = 2;
			}
		} else { //아이디 틀림
			$results[1] = 1;
		}

		return $results;
	}

	function SetParkInfo()
	{
		$env = new EnvVar();

		$this->MainDB = new MeekroDB($env->WebdcDBIP, $env->WebdcDBID, $env->WebdcDBPW, $env->WebdcDBName, $env->WebdcDBPort, 'utf8');

		$parksettingval = $this->MainDB->queryFirstRow("select * from parksetting");

		$_SESSION["Title"] = $parksettingval['Title'];
		$_SESSION["Address"] = $parksettingval['Address'];
		$_SESSION["Info"] = $parksettingval['Info'];
		$_SESSION["InfoTap"] = $parksettingval['InfoTap'];


		$this->ParkInfo = $this->MainDB->queryFirstRow("select * from sognoparkinfo");
	}

	function SetSognoDB()
	{
		$this->SognoDB = new MeekroDB($this->ParkInfo["DBIP"], $this->ParkInfo["DBUser"], $this->ParkInfo["DBPW"], $this->ParkInfo["DBName"], $this->ParkInfo["DBPort"], 'utf8');
	}

	function GetUserInfo($UserNo)
	{
		$tmpUserInfo = $this->MainDB->queryFirstRow("SELECT * FROM userinfo WHERE UserNo = %i", $UserNo);

		$subUserInfo = new SubUserInfo();
		$subUserInfo->UserNo = $tmpUserInfo["UserNo"];
		$subUserInfo->Unit = $tmpUserInfo["Unit"];
		$subUserInfo->Number = $tmpUserInfo["Number"];
		$subUserInfo->TelNum = $tmpUserInfo["TelNum"];
		$subUserInfo->UserClass = $tmpUserInfo["UserClass"];
		$subUserInfo->MemberDate = $tmpUserInfo["MemberDate"];

		$subUserInfo->UsedInfos = $this->MainDB->query("SELECT * FROM tiketusedinfo WHERE UserNo = %i AND UsedType != 99", $UserNo);

		return $subUserInfo;
	}


	//admin
	function SetUserInfos($offset = null)
	{
		$this->UserInfos = null;

		// 1. webdcuserinfo 테이블에서 모든 유저 정보를 가져옵니다.
		if ($offset != null) {
			$tmpUserInfos = $this->MainDB->query("SELECT * FROM userinfo WHERE Unit ASC, Number ASC LIMIT 200 OFFSET " . $offset);
		} else {
			$tmpUserInfos = $this->MainDB->query("SELECT * FROM userinfo WHERE Unit ASC, Number ASC");
		}

		$this->UserInfos = $tmpUserInfos;
	}



	function SetAdmin()
	{
	}

	//번호판 규격 검사
	function validatePlateNumber($plateNumber)
	{
		$plateNumber = trim($plateNumber); // 앞뒤 공백 제거
		$plateNumber = preg_replace('/\s+/', '', $plateNumber); // 모든 공백 제거

		//차량 번호판 규격 (숫자 2~3자리 + 한글 1자리 + 숫자 4자리)
		$vehiclePattern = "/^\d{2,3}[가-힣]\d{4}$/u"; // "123가1234" 형식

		//영업용 번호판 규격 (한글 2자리 + 숫자 2~3자리 + 한글 1자리 + 숫자 4자리)
		$businessPattern = "/^[가-힣]{2}\d{2,3}[가-힣]\d{4}$/u"; // "서울12가1234" 형식

		//차량 번호판 규격 검사(일반, 영업용 둘중 하나라도 해당이 되면 true)
		if (preg_match($vehiclePattern, $plateNumber) || preg_match($businessPattern, $plateNumber)) {
			return true;
		} else {
			return false;
		}
	}
}
