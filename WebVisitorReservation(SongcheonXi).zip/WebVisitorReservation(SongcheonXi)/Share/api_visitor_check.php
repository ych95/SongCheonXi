<?
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    require_once "../share/WebVisitorReserveManager.php";
    $wvrm = new WebVisitorReserveManager();
    $wvrm->SetParkInfo();

    $SognoParkNo = isset($_POST["SognoParkNo"]) ? $_POST["SognoParkNo"] : '';
    $CarNum = isset($_POST["CarNum"]) ? $_POST["CarNum"] : '';
    $VisitDate = isset($_POST["VisitDate"]) ? $_POST["VisitDate"] : '';

    $results["SognoParkNo"] = $SognoParkNo;
    $results["CarNum"] = $CarNum;

    //번호 규격 확인
    if(!$wvrm->validatePlateNumber($CarNum)){//비정상번호

    }else{
        if ($VisitDate == '') {
            $VisitDate = new DateTime();
            $VisitDate = $VisitDate->format('Y-m-d');
        } 

        $query = "SELECT * FROM daysreservation WHERE VisitDate = %s AND UsedType != 99 AND CarNum like %s";

        $result = $wvrm->MainDB->queryFirstRow($query, $VisitDate, "%".$CarNum."%");

        $results["VisitDate"] = $VisitDate;
        $results["VisitPurp"] = $result["VisitPurp"];
    }


    $wvrm->MainDB->disconnect();
    echo json_encode($results, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    exit();

}

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    require_once "../share/WebVisitorReserveManager.php";
    $wvrm = new WebVisitorReserveManager();
    $wvrm->SetParkInfo();

    $SognoParkNo = isset($_GET["SognoParkNo"]) ? $_GET["SognoParkNo"] : '';
    $CarNum = isset($_GET["CarNum"]) ? $_GET["CarNum"] : '';
    $VisitDate = isset($_GET["VisitDate"]) ? $_GET["VisitDate"] : '';

    $results["SognoParkNo"] = $SognoParkNo;
    $results["CarNum"] = $CarNum;

    //번호 규격 확인
    if(!$wvrm->validatePlateNumber($CarNum)){//비정상번호

    }else{
        if ($VisitDate == '') {
            $VisitDate = new DateTime();
            $VisitDate = $VisitDate->format('Y-m-d');
        } 
        $results["VisitDate"] = $VisitDate;

        $query = "SELECT * FROM daysreservation WHERE RegDate = %s AND CarNum like %s";

        $result = $wvrm->MainDB->queryFirstRow($query, $VisitDate, "%".$CarNum."%");

        if(!empty($result)){
            $results["Register"] = true;
        }else{
            $results["Register"] = false;
        }
    }


    $wvrm->MainDB->disconnect();
    echo json_encode($results, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    exit();

}

?>