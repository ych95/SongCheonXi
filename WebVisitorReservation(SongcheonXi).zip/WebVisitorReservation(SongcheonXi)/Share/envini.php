<?php

class EnvVar{
    //public $WebdcDBIP = "localhost";
    public $WebdcDBIP = "192.168.100.120";
    public $WebdcDBID = "sogno";
    public $WebdcDBPW = "sogno1234";
    public $WebdcDBName = "sogno_web_visitor";
    public $WebdcDBPort = 3306;
}
?>