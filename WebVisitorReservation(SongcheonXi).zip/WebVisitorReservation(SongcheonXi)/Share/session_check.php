<?php
session_start();

if(isset($_SESSION["UserClass"])){
    if ($_SESSION["UserClass"] == "0") {
        $location = "../Admin/adminMain.html";
    } else if ($_SESSION["UserClass"] == "1") {
        $location = "../User/userMain.html";
    }
}else{
    echo "alert('로그인 정보가 만료되었습니다.');";
    $location = "../Login/login.html";
    header("Location: ".$location);
	exit();
}

?>