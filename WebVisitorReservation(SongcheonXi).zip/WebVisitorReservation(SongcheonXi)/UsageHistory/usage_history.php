<?
require_once "../share/session_check.php";


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    require_once "../share/WebVisitorReserveManager.php";
    $wvrm = new WebVisitorReserveManager();
    $wvrm->SetParkInfo();

    $carNum = isset($_POST["CarNum"]) ? $_POST["CarNum"] : '';
    $visitDate = isset($_POST["VisitDate"]) ? $_POST["VisitDate"] : ''; //방문기준일을 설정안하면 오늘을 기준으로 조회

    //예약내역(tiketusedinfo) 조회
    if ($_SESSION["UserClass"] == "0") { //관리자는 모든 유저의 예약내역 조회

        //기준일이 없으면 전체 조회
        if ($visitDate == '') {
            $visitDate = new DateTime();
            $visitDate = $visitDate->format('Y-m-d');
        } 

        $query = "SELECT * FROM tiketusedinfo WHERE SognoParkNo = %s AND VisitDate = %s AND UsedType != 99 AND CarNum like %s ORDER BY CarNum ASC";

        $UsedInfos = $wvrm->MainDB->query($query, $wvrm->ParkInfo["SognoParkNo"], $visitDate, "%".$carNum."%");
    }

    $baseDate = null;
    $tableString = '';
    $visitCount = 0;
    $reservCount = 0;

    if (!empty($UsedInfos)) {
        $htmlString = 
        "<tbody>
            <tr>
                <td>차량번호</td>
                <td>비고</td>
                <td>이용여부</td>
            </tr>";

        foreach ($UsedInfos as $UsedInfo) {
            $htmlString = $htmlString.
            "<tr>
                <td>".$UsedInfo["CarNum"]."</td>
                <td>".$UsedInfo["VisitPurp"]."</td>";

                if(isset($UsedInfo["CarInDate"])){
                    $htmlString = $htmlString."<td>방문완료</td>";
                    $visitCount++;
                }else{
                    $htmlString = $htmlString."<td></td>";
                }
                $reservCount++;
        }

        $htmlString = $htmlString."</tr></tbody>";
    }else{
        $htmlString = "이용 내역이 존재하지 않습니다";
    }


    $results["HtmlString"] = $htmlString;
    $results["Count"] = $visitCount." / ".$reservCount." (방문/예약)";

    $wvrm->MainDB->disconnect();

    echo json_encode($results, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

    exit();
}
?>