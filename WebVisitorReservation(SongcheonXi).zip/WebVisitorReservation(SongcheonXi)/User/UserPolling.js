UserPolling();

const UserPolling = function () {
	$.ajax({
		url: "../Share/UserPolling.php",
		type: 'GET',
		data: { date: finalDate },
		dataType: 'json',
		success: function(response) {
			try {
				visitorReserveCount = response.count;
				
				if (response.logincheck === 'logout') {
					alert('로그인이 만료되었습니다. 다시 로그인 해주세요.');
					setTimeout(location.replace('../index.html'), 5000);
				} else {
					if (response.data && response.data.length > 0) {
						// 구매 요청 알림
						let tag = "<div class='notification notification-info' id='notification notification-info'>추가등록 요청건이 존재합니다.</div>";
						$('#notification-container-admin').html(tag);
					}
				}
			} catch (error) {
				// 예외 처리 (Ajax 실패 시)
				console.error('처리 중 오류 발생', error);
			}
		},
		error: function(jqXHR, textStatus, errorThrown) {
			console.error('AJAX 요청 오류:', jqXHR, textStatus, errorThrown);
		}
	});
}

$(document).ready(function() {
	setInterval(UserPolling, 10000);  // 10000ms = 10초
});