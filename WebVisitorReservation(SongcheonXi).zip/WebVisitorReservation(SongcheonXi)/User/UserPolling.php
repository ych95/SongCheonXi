<?php
@set_time_limit(0);

session_start();

require_once "../share/db.class.php";
require_once "../share/WebVisitorReserveManager.php";
try {
    $wvrm = new WebVisitorReserveManager();
    $wvrm->SetParkInfo();

    $_SESSION["UserNo"] = 0;
    // // 세션이 없으면 바로 로그아웃 처리
    // if (!isset($_SESSION["UserNo"])) {
    //     session_unset();
    //     session_destroy();

    //     // 세션 ID를 제거 (쿠키에서 세션 ID를 삭제해야 완전한 종료)
    //     setcookie(session_name(), '', time() - 3600, '/'); // 세션 쿠키 만료
    //     session_regenerate_id(true);  // 세션 ID 새로 생성 (보안상 권장)

    //     $db->MainDB->disconnect();
    //     echo json_encode(array('count' => 0, 'logincheck' => 'logout'));
    //     exit();
    // }

    $wvrm->SetSognoDB();

    //방문예약차량 리스트 검색
    $res = $wvrm->MainDB->query("SELECT * FROM tiketusedinfo WHERE (UsedType = 1 or UsedType = 2) and UserNo = {$_SESSION['UserNo']}");

    if (!empty($res)) {
        foreach ($res as $item) {
            //방문예약 차량이 아직 입출차 업데이트가 안되어있다면
            if($item['UsedType'] == 1){
                //해당 차량 입출차 기록 조회
                $cariodatas = $wvrm->SognoDB->query("SELECT * FROM cariodata WHERE GroupName is not null and InCarNum1 = '{$item['CarNum']}' and InDate >= '{$item['VisitDate']}' and InDate < DATE_ADD(DATE('{$item['VisitDate']}'), INTERVAL 1 DAY);");

                var_dump( $cariodatas);
                //입차를 했으면
                if (!empty($cariodatas)) {
                    foreach ($cariodatas as $cariodata) {
                        //출차까지 되었으면
                        if(isset($cariodata['OutDate'])){
                            $wvrm->MainDB->query("UPDATE tiketusedinfo SET TKNo = '{$cariodata['TKNo']}', CarInDate = '{$cariodata['InDate']}', LPRImage = '{$cariodata['InImage1']}',
                            UsedType = 3 WHERE UserNo = {$_SESSION['UserNo']} and CarNum = '{$item['CarNum']}' and UsedType != 4");
                        }else{
                            $wvrm->MainDB->query("UPDATE tiketusedinfo SET TKNo = '{$cariodata['TKNo']}', CarInDate = '{$cariodata['InDate']}', LPRImage = '{$cariodata['InImage1']}',
                            UsedType = 2 WHERE UserNo = {$_SESSION['UserNo']} and TKNo is null and CarNum = '{$item['CarNum']}' and UsedType = 1");
                        }
                    }
                }
            }else if($item['UsedType'] == 2){//방문예약 차량이 입차중인경우
                //해당 차량 입출차 기록 조회
                $cariodatas = $wvrm->SognoDB->query("SELECT * FROM cariodata WHERE GroupName is not null and InCarNum1 = '{$item['CarNum']}' and InDate >= '{$item['VisitDate']}' and InDate < DATE_ADD(DATE('{$item['VisitDate']}'), INTERVAL 1 DAY);");

                if (!empty($cariodatas)) {
                    foreach ($cariodatas as $cariodata) {
                        //출차했으면
                        if(isset($cariodata['OutDate'])){
                            $wvrm->MainDB->query("UPDATE tiketusedinfo SET UsedType = 3 WHERE UserNo = {$_SESSION['UserNo']} and TKNo = '{$cariodata['TKNo']}' and UsedType = 2");
                        }
                    }
                }
            }
        }
    }

    $res = $db->MainDB->query('SELECT * FROM tiketusedinfo WHERE UsedType = 1 or UsedType = 2');

    $reserveCount = 0;
    $InCount = 0;

    if (!empty($res)) {
        foreach ($res as $item) {
            if($item['UsedType'] == 1){
                $reserveCount++;
            }else{
                $InCount++;
            }
        }
    }

    $wvrm->MainDB->disconnect();
    $wvrm->SognoDB->disconnect();
    // 정상적인 JSON 응답
    echo json_encode(array('reserveCount' => $reserveCount, 'InCount' => $InCount, 'logincheck' => 'login'));
} catch (Exception $e) {
    $wvrm->MainDB->disconnect();
    $wvrm->SognoDB->disconnect();
    // 예외가 발생했을 때 JSON 형식으로 오류 메시지 반환
    echo json_encode(array('error' => 'Server error: ' . $e->getMessage()));
}

?>