<?php
require_once "../share/session_check.php";

require_once "../share/WebVisitorReserveManager.php";

header('Content-Type: application/json');

$wvrm = new WebVisitorReserveManager();
$wvrm->SetParkInfo();

    $type = isset($_GET['Type']) ? $_GET['Type'] : '';

    if ($type == 'Unit') {
        // 중복 없이 동 리스트 가져오기
        $result = $wvrm->MainDB->query("SELECT DISTINCT Unit FROM aptunitinfo ORDER BY Unit ASC");
        $data = [];
        foreach ($result as $row) {
            $data[] = $row;
        }
        echo json_encode($data);
    } elseif ($type == 'Number' && isset($_GET['Unit'])) {
        // 선택한 동에 해당하는 호수 가져오기
        $result = $wvrm->MainDB->query("SELECT Number FROM aptunitinfo WHERE Unit=%s ORDER BY Number ASC", $_GET['Unit']);
        $data = [];
        foreach ($result as $row) {
            $data[] = $row;
        }
        echo json_encode($data);
    }

    $wvrm->MainDB->disconnect();
    exit();
?>