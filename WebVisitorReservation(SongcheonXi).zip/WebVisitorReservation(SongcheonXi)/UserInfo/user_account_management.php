<?
require_once "../share/session_check.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

	require_once "../Share/WebVisitorReserveManager.php";

	$wvrm = new WebVisitorReserveManager();
	$wvrm->SetParkInfo();

	$type = isset($_POST["Type"]) ? $_POST["Type"] : "Search";
	$unit = isset($_POST["Unit"]) ? $_POST["Unit"] : "";
	$number = isset($_POST["Number"]) ? $_POST["Number"] : "";
	$userNo = isset($_POST["UserNo"]) ? $_POST["UserNo"] : "";
	
	//유저 목록 검색
	if($type == "Search"){
		if($unit == "" && $number == ""){//검색어가 없으면 전체조회
			$query = "SELECT * FROM userinfo WHERE Activated = 1";
			$UserInfos = $wvrm->MainDB->query($query);
		}else{//검색어가 있다면
			$unit = "%".$unit."%";
			$number = "%".$number."%";
			$query = "SELECT * FROM userinfo WHERE Unit Like %s AND Number Like %s AND Activated = 1";
			$UserInfos = $wvrm->MainDB->query($query, $unit, $number);
		}
		
		if(!empty($UserInfos)){
			$htmltext = 
			"<tbody>
				<tr>
					<td>동</td>
					<td>호수</td>
					<td>전화</td>
					<td>탈퇴처리</td>
				</tr>";

			foreach ($UserInfos as $UserInfo) {
				$htmltext = $htmltext.
				"<tr>
					<td>".$UserInfo["Unit"]."</td>
					<td>".$UserInfo["Number"]."</td>
					<td>".$UserInfo["TelNum"]."</td>
					<td><button class='reset-btn' data-userno=".$UserInfo["UserNo"]." data-unit=".$UserInfo["Unit"]." data-number=".$UserInfo["Number"].">탈퇴</button></td>
				</tr>";
			}

			$htmltext = $htmltext."</tbody>";
		}else{
			$htmltext = "계정이 존재하지 않습니다";
		}
	}
	
	//유저 초기화
	else if($type == "Unsubscribe"){
		//초기화전 유저가 예약한 내역 찾아 무효처리
		//먼저 tiketusedinfo테이블에서 유효한 예약기록 확인
		$query = "SELECT * FROM tiketusedinfo WHERE UserNo = %i AND VisitDate >= CURDATE() AND UsedType != %i";
		$usertiketusedinfos = $wvrm->MainDB->query($query, $userNo, 99);

		if(!empty($usertiketusedinfos)){
			foreach ($usertiketusedinfos as $usertiketusedinfo) {
				$query = "SELECT * FROM tiketusedinfo WHERE UserNo != %i AND VisitDate = %s AND UsedType != %i AND CarNum = %s";
				$othertiketusedinfo = $wvrm->MainDB->query($query, $userNo, $usertiketusedinfo["VisitDate"], 99, $usertiketusedinfo["CarNum"]);
		
				// 다른 유저의 등록이 없다면 daysreservation 차량 예약 삭제		
				if (empty($othertiketusedinfo)) {
					$query = "DELETE FROM daysreservation WHERE CarNum = %s AND RegDate = %s";
					$wvrm->MainDB->query($query, $usertiketusedinfo["CarNum"], $usertiketusedinfo["VisitDate"]);
				}
				
				//유저의 남은 예약 취소 (UsedType을 99로 설정)
				$query = "UPDATE tiketusedinfo SET UsedType = 99 WHERE UserNo = %i AND VisitDate = %s";
				$wvrm->MainDB->query($query, $userNo, $usertiketusedinfo["VisitDate"]);
			}
		}

		//유저정보 초기화
		$query = "UPDATE userinfo SET Activated = 0 WHERE UserNo = %i";
		$wvrm->MainDB->query($query, $userNo);
	}


	$wvrm->MainDB->disconnect();

	echo $htmltext;

	exit();
}
