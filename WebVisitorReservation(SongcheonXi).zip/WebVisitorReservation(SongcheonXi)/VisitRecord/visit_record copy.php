<?
require_once "../share/session_check.php";

    if ($_SERVER["REQUEST_METHOD"] == "POST") {

        require_once "../share/WebVisitorReserveManager.php";
        $wvrm = new WebVisitorReserveManager();
        $wvrm->SetParkInfo();

        $carNum = isset($_POST["CarNum"]) ? $_POST["CarNum"] : '';

        $visitDate = isset($_POST["VisitDate"]) ? $_POST["VisitDate"] : ''; //방문기준일을 설정안하면 오늘을 기준으로 조회

        $userNo = $_SESSION['UserNo'];

        //예약내역(tiketusedinfo) 조회
        if($_SESSION["UserClass"] == "0"){//관리자는 모든 유저의 예약내역 조회

            //기준일이 없으면 전체 조회
            if($visitDate == ''){
                $visitDate = new DateTime();
                $visitDate = $visitDate->format('Y-m-d');
                $query = "SELECT * FROM tiketusedinfo WHERE SognoParkNo = %s AND CarNum like %s AND VisitDate < %s AND UsedType != 99 order by VisitDate ASC";
            }
            else{
                $query = "SELECT * FROM tiketusedinfo WHERE SognoParkNo = %s AND CarNum like %s AND VisitDate = %s AND UsedType != 99 order by VisitDate ASC";
            }

            $UsedInfos = $wvrm->MainDB->query($query, $wvrm->ParkInfo["SognoParkNo"], "%".$carNum."%", $visitDate);
        
        }else{//유저는 자기자신 것 만 조회
             //기준일이 없으면 전체 조회
             if($visitDate == ''){
                $visitDate = new DateTime();
                $visitDate = $visitDate->format('Y-m-d');

                $query = "SELECT * FROM tiketusedinfo WHERE UserNo = %s AND SognoParkNo = %s AND CarNum like %s AND VisitDate < %s AND UsedType != 99 order by VisitDate ASC";
            }else{
                $query = "SELECT * FROM tiketusedinfo WHERE UserNo = %s AND SognoParkNo = %s AND CarNum like %s AND VisitDate = %s AND UsedType != 99 order by VisitDate ASC";
            }

            $UsedInfos = $wvrm->MainDB->query($query, $userNo, $wvrm->ParkInfo["SognoParkNo"], "%".$carNum."%", $visitDate);
        }

        //echo sprintf($query, $userNo, $wvrm->ParkInfo["SognoParkNo"], "%".$carNum."%", $visitDate);

        $baseDate = null;
        $htmlString = '';

        if(!empty($UsedInfos)){
            foreach ($UsedInfos as $UsedInfo) {

                if(!isset($baseDate) || $baseDate != $UsedInfo["VisitDate"]){
                    $baseDate = $UsedInfo["VisitDate"];
                    $htmlString = $htmlString."<tr><td class='visit_date'>".$baseDate."</td></tr>";
                }

                $htmlString = $htmlString."<tr>
                                                <td class='visit-list-row' id='".$baseDate."_".$UsedInfo["CarNum"]."'>
                                                    <div class='visit-list-cell'>
                                                        <span>".$UsedInfo["CarNum"]."</span>
                                                        <hr>
                                                        <span>".$UsedInfo["VisitPurp"]."</span>
                                                    </div>
                                                </td>
                                            </tr>";
            }
        }
        else{
            $htmlString = "<tr><td class='visit_date'>".$visitDate."</td></tr>";
            $htmlString = $htmlString."<tr><td class='visit-list-row' id='".$baseDate."_'>기록이 없습니다.</td></tr>";
        }

        $wvrm->MainDB->disconnect();
     
        echo $htmlString;
        exit();
    }
?>