<?
require_once "../share/session_check.php";

    // if (!isset($_SESSION['Unit']) || !isset($_SESSION['Number']) || !isset($_SESSION["UserNo"])) {
    //     $_SESSION['VisitReserveMessage'] = "세션 정보가 유효하지 않습니다.";
    //     header("Location: ../VisitReservation/visit_reservation.html");
    //     exit();
    // }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {

        require_once "../share/WebVisitorReserveManager.php";
        $wvrm = new WebVisitorReserveManager();
        $wvrm->SetParkInfo();

        $carNum = $_POST["CarNum"];
        $visitDate = $_POST["VisitDate"];
        $visitPurp = $_POST["VisitPurp"];

        $_SESSION["CarNum"] =  $carNum;
        $_SESSION["VisitDate"] = $visitDate;
        $_SESSION["VisitPurp"] = $visitPurp;

        $userDept = $_SESSION["Unit"]."/".$_SESSION["Number"];

        // 번호판 유효성 검사
        // 정상차량 번호이면...
        if ($wvrm->validatePlateNumber($carNum)) {

            // UserNo, SognoParkNo, CarNum, VisitDate를 비교하여 해당 차량이 연장등록 조건인지 아닌지 확인
            $result = $wvrm->MainDB->queryFirstRow("SELECT * FROM tiketusedinfo WHERE UserNo = %i AND SognoParkNo = %i AND CarNum = %s AND VisitDate = DATE_SUB(%s, INTERVAL 1 DAY) LIMIT 1", $_SESSION['UserNo'], $wvrm->ParkInfo["SognoParkNo"], $carNum, $visitDate);

            //연장등록 인 경우(연속된 직전 날짜가 한개이상 존재)
            if ($result) {
                //연속된 직전 날짜의 UsedCount 값이 MaxTime 미만일경우 연장가능
                if($result["UsedCount"] < $wvrm->ParkInfo["MaxTime"]){
                                
                    // tiketusedinfo 테이블에 누가 방문차량을 등록했는지에 대한 정보 저장
                    //연장 인서트 할때는 UsedCount가 직전 일자 기록의 UsedCount에 1을 더한 값을 반영(몇번째 연장인지 파악하기 위함)
                    $wvrm->MainDB->query("INSERT IGNORE INTO tiketusedinfo (UserNo, SognoParkNo, CarNum, UsedDate, VisitDate, UsedType, UsedCount, VisitPurp) VALUES (%i, %i, %s, now(), %s, %i, %i+1, %s)", $_SESSION['UserNo'], $wvrm->ParkInfo["SognoParkNo"], $carNum, $visitDate, 4, $result["UsedCount"], $visitPurp);      

                    // daysreservation 테이블에 방문차량과 방문일시를 저장(같은날 같은차량의 경우 저장안함)
                    $wvrm->MainDB->query("INSERT IGNORE INTO daysreservation (CarNum, RegDate) VALUES (%s, %s)", $carNum, $visitDate);

                    $_SESSION['VisitReserveMessage'] = "연장 되었습니다.";
                    $location = "../VisitReservationList/visit_reservation_list.html";
                }
                //더이상 연장이 불가능한 경우(이미 MaxTime만큼 연장됨)
                else{
                    $_SESSION['VisitReserveMessage'] = "최대 연장 일수를 초과하여 더이상 연장 할 수 없습니다.";
                    $location = "../VisitReservation/visit_reservation.html";
                }
            }
            //연속된 날짜가 없는 일반등록 인 경우
            else{
                // tiketusedinfo 테이블에 누가 방문차량을 등록했는지에 대한 정보 저장
                $result = $wvrm->MainDB->query("INSERT IGNORE INTO tiketusedinfo (UserNo, SognoParkNo, CarNum, UsedDate, VisitDate, VisitPurp) VALUES (%i, %i, %s, now(), %s, %s)", $_SESSION['UserNo'], $wvrm->ParkInfo["SognoParkNo"], $carNum, $visitDate, $visitPurp);      

                // daysreservation 테이블에 방문차량과 방문일시를 저장(같은날 같은차량의 경우 저장안함)
                $wvrm->MainDB->query("INSERT IGNORE INTO daysreservation (CarNum, RegDate) VALUES (%s, %s)", $carNum, $visitDate);

                $_SESSION['VisitReserveMessage'] = "예약이 완료되었습니다.";
                $location = "../VisitReservationList/visit_reservation_list.html";            
            }

            
        }
        //비정상 차량번호이면...
        else {
            $_SESSION['VisitReserveMessage'] = "유효하지 않은 번호판입니다.";
            $location = "../VisitReservation/visit_reservation.html";
        }

        $wvrm->MainDB->disconnect();
        header("Location: ".$location);
        exit();
    }
?>