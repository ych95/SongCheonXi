<?
require_once "../share/session_check.php";

// if (!isset($_SESSION['Unit']) || !isset($_SESSION['Number']) || !isset($_SESSION["UserNo"])) {
//     $_SESSION['VisitReserveMessage'] = "세션 정보가 유효하지 않습니다.";
//     header("Location: ../VisitReservation/visit_reservation.html");
//     exit();
// }

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        require_once "../share/WebVisitorReserveManager.php";
        $wvrm = new WebVisitorReserveManager();
        $wvrm->SetParkInfo();

        $carNum = $_POST["CarNum"];
        $visitDate = $_POST["VisitDate"];
        $visitPurp = $_POST["VisitPurp"];

        $_SESSION["CarNum"] =  $carNum;
        $_SESSION["VisitDate"] = $visitDate;
        $_SESSION["VisitPurp"] = $visitPurp;

        $userDept = $_SESSION["Unit"] . "/" . $_SESSION["Number"];

        // 번호판 유효성 검사
        // 정상차량 번호이면...
        if ($wvrm->validatePlateNumber($carNum)) {
            try {
                $query = "SELECT VisitDate FROM tiketusedinfo
                                    WHERE UserNo = %i
                                    AND SognoParkNo = %s
                                    AND CarNum = %s
                                    AND VisitDate BETWEEN DATE_SUB(%s, INTERVAL %i DAY) 
                                    AND DATE_ADD(%s, INTERVAL %i DAY) ORDER BY VisitDate";

                $existingDates = $wvrm->MainDB->queryFirstColumn($query, $_SESSION['UserNo'], $wvrm->ParkInfo["SognoParkNo"], $carNum, $visitDate, $wvrm->ParkInfo["MaxTime"], $visitDate, $wvrm->ParkInfo["MaxTime"]);

                // 입력한 날짜 추가 후 정렬
                $existingDates[] = $visitDate;
                sort($existingDates);

                // 연속된 날짜 개수 판별
                $maxConsecutiveDays = 1;
                $currentStreak = 1;

                for ($i = 1; $i < count($existingDates); $i++) {
                    $prevDate = strtotime($existingDates[$i - 1]);
                    $currDate = strtotime($existingDates[$i]);

                    if (($currDate - $prevDate) === 86400) { // 하루 차이 (1일 = 86400초)
                        $currentStreak++;
                        $maxConsecutiveDays = max($maxConsecutiveDays, $currentStreak);
                    } else {
                        $currentStreak = 1; // 연속이 끊기면 초기화
                    }
                }

                // 연속된 날짜 개수가 MaxTime일을 초과하면 연장 차단
                if ($maxConsecutiveDays > $wvrm->ParkInfo["MaxTime"]) {
                    $visitReserveMessage = "연속 " . $wvrm->ParkInfo["MaxTime"] . "일 이상 등록할 수 없습니다.(종합: " . $maxConsecutiveDays . "일)";
                    $location = "../VisitReservation/visit_reservation.html";
                }

                // 일반적인 연장등록의 경우                   
                else if ($maxConsecutiveDays <= $wvrm->ParkInfo["MaxTime"] && $maxConsecutiveDays > 1) {

                    // tiketusedinfo 테이블에 누가 방문차량을 등록했는지에 대한 정보 저장
                    $wvrm->MainDB->query("INSERT IGNORE INTO tiketusedinfo (UserNo, SognoParkNo, CarNum, UsedDate, VisitDate, UsedType, VisitPurp) VALUES (%i, %i, %s, now(), %s, %s)", $_SESSION['UserNo'], $wvrm->ParkInfo["SognoParkNo"], $carNum, $visitDate, $visitPurp);

                    // daysreservation 테이블에 방문차량과 방문일시를 저장(같은날 같은차량의 경우 저장안함)
                    $wvrm->MainDB->query("INSERT IGNORE INTO daysreservation (CarNum, RegDate) VALUES (%s, %s)", $carNum, $visitDate);

                    $visitReserveMessage = $visitDate . " / " . $carNum . " 예약이 연장 되었습니다.(종합: " . $maxConsecutiveDays . "일)";
                    $location = "../VisitReservationList/visit_reservation_list.html";
                }

                //연속된 날짜가 없는 일반등록 인 경우
                else {
                    // tiketusedinfo 테이블에 누가 방문차량을 등록했는지에 대한 정보 저장
                    $result = $wvrm->MainDB->query("INSERT IGNORE INTO tiketusedinfo (UserNo, SognoParkNo, CarNum, UsedDate, VisitDate, VisitPurp) VALUES (%i, %i, %s, now(), %s, %s)", $_SESSION['UserNo'], $wvrm->ParkInfo["SognoParkNo"], $carNum, $visitDate, $visitPurp);

                    // daysreservation 테이블에 방문차량과 방문일시를 저장(같은날 같은차량의 경우 저장안함)
                    $wvrm->MainDB->query("INSERT IGNORE INTO daysreservation (CarNum, RegDate) VALUES (%s, %s)", $carNum, $visitDate);

                    $visitReserveMessage = $visitDate . " / " . $carNum . " 예약이 완료 되었습니다.";
                    $location = "../VisitReservationList/visit_reservation_list.html";
                }
            } catch (Exception $e) {
                $visitReserveMessage = "예약 등록 오류";
            }
        }
        //비정상 차량번호이면...
        else {
            $visitReserveMessage = "유효하지 않은 번호입니다.(" . $carNum . ")";
            $location = "../VisitReservation/visit_reservation.html";
        }
    } catch (Exception $e) {
        $visitReserveMessage = "서버 오류";
    }

    $_SESSION['VisitReserveMessage'] = $visitReserveMessage;

    $wvrm->MainDB->disconnect();
    header("Location: " . $location);
    exit();
}
