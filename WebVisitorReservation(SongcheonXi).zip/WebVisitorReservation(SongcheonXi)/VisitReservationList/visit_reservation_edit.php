<?
    require_once "../share/session_check.php";

    try {
        if ($_SERVER["REQUEST_METHOD"] == "POST") {

            require_once "../share/WebVisitorReserveManager.php";
            $wvrm = new WebVisitorReserveManager();
            $wvrm->SetParkInfo();

            $usedInfoNo = isset($_POST["UsedInfoNo"]) ? $_POST["UsedInfoNo"] : '';
            $visitDate = isset($_POST["VisitDate"]) ? $_POST["VisitDate"] : ''; //방문기준일을 설정안하면 오늘로 설정
            $visitPurp = isset($_POST["VisitPurp"]) ? $_POST["VisitPurp"] : '';
            $carNum = isset($_POST["CarNum"]) ? $_POST["CarNum"] : '';
            $type = isset($_POST["Type"]) ? $_POST["Type"] : 0; //예약수정:0, 예약삭제:1

            if($_SESSION["UserClass"] == "0"){
                $visitPurp = "(관리사무소등록)".$visitPurp;
            }
            
            // 입력 값이 없거나 잘못된 경우 처리
            if (empty($usedInfoNo)) {
                $visitReserveMessage = "잘못된 입력값입니다.";
            }else{
                //tiketusedinfo 매칭
                $query = "SELECT * FROM tiketusedinfo WHERE UsedInfoNo = %i";
                $oritiketusedinfo = $wvrm->MainDB->queryFirstRow($query, $usedInfoNo);

                if(!empty($oritiketusedinfo)){
                    //변경전 기존 예약날 같은차량으로 다른 유저가 등록한 내역이있는지 검사
                    $query = "SELECT * FROM tiketusedinfo WHERE UserNo != %i AND VisitDate = %s AND UsedType != %i AND CarNum = %s";
                    $othertiketusedinfo = $wvrm->MainDB->query($query, $_SESSION['UserNo'], $oritiketusedinfo["VisitDate"], 99, $carNum);

                    if($type == 0){
                        try {
                            $query = "SELECT VisitDate FROM tiketusedinfo
                                    WHERE UserNo = %i
                                    AND SognoParkNo = %s
                                    AND CarNum = %s
                                    AND VisitDate != %s
                                    AND VisitDate BETWEEN DATE_SUB(%s, INTERVAL %i DAY) 
                                    AND DATE_ADD(%s, INTERVAL %i DAY) ORDER BY VisitDate";
                  
                            $existingDates = $wvrm->MainDB->queryFirstColumn($query, $_SESSION['UserNo'], $wvrm->ParkInfo["SognoParkNo"], $carNum, $oritiketusedinfo["VisitDate"], $visitDate, $wvrm->ParkInfo["MaxTime"], $visitDate, $wvrm->ParkInfo["MaxTime"]);

                            // 입력한 날짜 추가 후 정렬
                            $existingDates[] = $visitDate;
                            sort($existingDates);

                            // 연속된 날짜 개수 판별
                            $maxConsecutiveDays = 1;
                            $currentStreak = 1;

                            for ($i = 1; $i < count($existingDates); $i++) {
                                $prevDate = strtotime($existingDates[$i - 1]);
                                $currDate = strtotime($existingDates[$i]);
                                
                                if (($currDate - $prevDate) === 86400) { // 하루 차이 (1일 = 86400초)
                                    $currentStreak++;
                                    $maxConsecutiveDays = max($maxConsecutiveDays, $currentStreak);
                                } else {
                                    $currentStreak = 1; // 연속이 끊기면 초기화
                                }
                            }
                            
                            // 연속된 날짜 개수가 MaxTime일을 초과하면 연장 차단
                            if ($maxConsecutiveDays > $wvrm->ParkInfo["MaxTime"]) {

                                $visitReserveMessage = "연속 ".$wvrm->ParkInfo["MaxTime"]."일 이상 등록할 수 없습니다.(종합: ".$maxConsecutiveDays."일)";
                            } 

                            // 일반적인 연장등록의 경우                   
                            else if ($maxConsecutiveDays <= $wvrm->ParkInfo["MaxTime"] && $maxConsecutiveDays > 1){
                                $query = "UPDATE tiketusedinfo SET VisitDate = %s, VisitPurp = %s WHERE UsedInfoNo = %s";
                                $wvrm->MainDB->query($query, $visitDate, $visitPurp, $usedInfoNo);

                                // 다른 유저의 등록이 없다면 daysreservation 차량 예약일 변경	
                                if (empty($othertiketusedinfo)){
                                    $query = "UPDATE daysreservation SET RegDate = %s WHERE CarNum = %s AND RegDate = %s";
                                    $wvrm->MainDB->query($query, $visitDate, $carNum, $oritiketusedinfo["VisitDate"]);
                                }

                                $visitReserveMessage = $carNum." ".$oritiketusedinfo["VisitDate"]."->".$visitDate." 예약 변경 되었습니다.(종합 ".$maxConsecutiveDays."일)";
                            } 

                            // 연속된 날짜가 없는 일반등록 인 경우
                            else {
                                $query = "UPDATE tiketusedinfo SET VisitDate = %s, VisitPurp = %s WHERE UsedInfoNo = %s";
                                $wvrm->MainDB->query($query, $visitDate, $visitPurp, $usedInfoNo);  

                                // 다른 유저의 등록이 없다면 daysreservation 차량 예약일 변경	
                                if (empty($othertiketusedinfo)){
                                    $query = "UPDATE daysreservation SET RegDate = %s WHERE CarNum = %s AND RegDate = %s";
                                    $wvrm->MainDB->query($query, $carNum, $visitDate, $oritiketusedinfo["VisitDate"]);
                                }

                                $visitReserveMessage = $carNum." ".$oritiketusedinfo["VisitDate"]."->".$visitDate." 예약 변경 되었습니다.";
                            }
                        }catch (Exception $e) {
                            $visitReserveMessage = "예약 변경 오류";
                        }
                    }else{
                        try {
                            $query = "UPDATE tiketusedinfo SET UsedType = %i WHERE UsedInfoNo = %s";
                            $wvrm->MainDB->query($query, 99, $usedInfoNo);
    
                            // 다른 유저의 등록이 없다면 daysreservation 차량 예약 삭제		
                            if (empty($othertiketusedinfo)){
                                $query = "DELETE FROM daysreservation WHERE CarNum = %s AND RegDate = %s";
                                $wvrm->MainDB->query($query, $carNum, $visitDate);
                            }
    
                            $visitReserveMessage = $visitDate." / ".$carNum." 예약 삭제 되었습니다.";
                        }catch (Exception $e) {
                            $visitReserveMessage = "예약 삭제 실패 다시 시도하여 주세요.";
                        }
                    }
                } 
            }
        }
    }catch (Exception $e) {
        $visitReserveMessage = "서버 오류"; 
    }

    echo $visitReserveMessage;

    $wvrm->MainDB->disconnect();
    exit();
?>